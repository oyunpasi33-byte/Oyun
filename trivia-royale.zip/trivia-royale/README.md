# 🏰 Kale Yarışması

İki kişilik, gerçek zamanlı (Socket.io tabanlı), RPG temalı strateji + genel kültür bilgi yarışması.
Her oyuncu kendi köyünü/kalesini yönetir: doğru cevaplar köyü büyütür, yanlış cevaplar köylü/asker
kaybettirir. Art arda doğru cevaplar **sabotaj** hakkı, yeterli asker ise rakibe **akın** düzenleme
imkânı verir.

## 📁 Proje Yapısı

```
trivia-royale/
├── server/                 # Node.js + Express + Socket.io backend
│   ├── index.js             # Giriş noktası, HTTP + Socket.io sunucusu
│   ├── gameManager.js        # Oda/oyun durumu, soru akışı, sabotaj/akın mantığı
│   ├── questions.js          # Genel kültür soru bankası
│   └── package.json
└── client/                 # Statik frontend (build aracı gerekmez)
    ├── index.html            # Tek sayfa: giriş, lobi, oyun, oyun sonu ekranları
    ├── css/style.css         # Özgün RPG/kuşatma temalı tasarım
    └── js/app.js             # Socket.io istemcisi + render mantığı
```

Backend, `client/` klasörünü statik dosya olarak sunduğu için **tek bir sunucu** yeterlidir;
ayrı bir frontend build/deploy sürecine gerek yoktur.

## ⚙️ Kurulum

Gereksinim: [Node.js](https://nodejs.org) 18 veya üzeri.

```bash
cd trivia-royale/server
npm install
npm start
```

Sunucu `http://localhost:3000` adresinde ayağa kalkar. Terminalde şunu görmelisin:

```
Kale Yarışması sunucusu http://localhost:3000 adresinde çalışıyor
```

Geliştirme sırasında dosya değişikliklerinde otomatik yeniden başlatma için:

```bash
npm run dev
```

## 🎮 Nasıl Oynanır (İki Cihazdan)

1. Bir oyuncu `http://localhost:3000` adresini açar, adını girer ve **"Yeni Kale Kur"** der.
   Ekranda 5 haneli bir **oda kodu** görünür (ör. `K7X2M`).
2. Bu oyuncu, sağ üstteki **"Davet Linkini Kopyala"** butonuna basıp linki arkadaşına
   (WhatsApp, mesaj vb. ile) gönderir. Link şu formattadır:
   `http://<bilgisayarının-ip-adresi>:3000/?room=K7X2M`
3. Arkadaşı bu linki kendi telefonundan/bilgisayarından açar (veya ana sayfadan
   **"Odaya Katıl"** sekmesine geçip kodu elle girer).
4. İki oyuncu da lobide **"Hazırım"** butonuna bastığında oyun otomatik başlar.
5. Kapıya gelen ziyaretçilerin sorularını süresi içinde cevaplayın, art arda doğru
   bilerek sabotaj hakkı kazanın, yeterli askeriniz olunca rakibe akın düzenleyin.
6. 5 dakika dolduğunda veya bir kale tamamen çöktüğünde kazanan belirlenir.

### 🌐 Aynı Wi-Fi'daki İki Farklı Cihazdan Test Etmek İçin

Eğer sunucuyu kendi bilgisayarında çalıştırıyorsan ve arkadaşın aynı Wi-Fi ağındaki
telefonundan bağlanacaksa, `localhost` yerine bilgisayarının yerel ağ IP adresini kullanmalısınız:

- **Windows:** `ipconfig` komutuyla "IPv4 Adresi"ni bul (ör. `192.168.1.24`)
- **macOS/Linux:** `ifconfig` veya `ip addr` ile yerel IP'yi bul

Arkadaşın tarayıcısından `http://192.168.1.24:3000` adresine gitmesi yeterlidir.
Gerçek internet üzerinden (farklı ağlardaki cihazlarla) oynamak için ise projeyi bir
sunucuya **deploy** etmen gerekir (aşağıya bakınız).

## ☁️ Yayına Alma (Deploy)

Proje, Socket.io kullandığı için **her zaman çalışan (persistent) bir Node.js sunucusu**
gerektirir — statik hosting (yalnızca dosya sunan) platformlar yeterli değildir. Uygun ücretsiz/
uygun fiyatlı seçenekler:

- **Render.com** → "Web Service" oluştur, root dizin olarak `server/` klasörünü göster,
  build komutu `npm install`, start komutu `npm start`.
- **Railway.app** → benzer şekilde `server/` klasörünü deploy et.
- **Fly.io** veya kendi VPS'in → `pm2` ile `npm start` sürecini ayakta tutabilirsin.

Deploy ettikten sonra verilen public URL'yi (`https://kale-yarismasi.onrender.com` gibi)
sen ve arkadaşın doğrudan tarayıcınızdan açabilirsiniz — artık aynı ağda olmanıza gerek kalmaz.

> Not: `server/index.js` içindeki Socket.io CORS ayarı geliştirme kolaylığı için `origin: '*'`
> olarak bırakıldı. Gerçek bir production ortamında bunu kendi domain'inle sınırlamak
> güvenlik açısından daha doğru olur.

## 🧠 Oyun Mekaniklerinin Teknik Özeti

| Mekanik | Değer (server/gameManager.js içinde ayarlanabilir) |
|---|---|
| Oyun süresi | 5 dakika |
| Başlangıç köylü / asker | 20 köylü / 4 asker |
| Soru süresi | 14 saniye (sabotajla 8 saniyeye düşer) |
| Sabotaj hakkı | 3 art arda doğru cevapla kazanılır |
| Akın için gereken asker | 8 |
| Akın bekleme süresi | 25 saniye |
| Kazanma koşulu | Süre sonunda en çok (köylü + asker×2) puanına sahip taraf, ya da rakip kalesi tamamen çökerse anında |

Tüm bu sayılar `server/gameManager.js` dosyasının en üstündeki sabitlerden kolayca
değiştirilebilir; soru bankası ise `server/questions.js` içinde — istediğin kadar yeni
soru ekleyebilirsin (kategori/zorluk alanlarını doldurman yeterli).

## 🛠️ Genişletme Fikirleri

- Soru bankasını bir JSON dosyasından veya API'den dinamik çekmek
- Skorbord / geçmiş maçlar için basit bir veritabanı (SQLite) eklemek
- Sesli efektler (doğru/yanlış, akın, sabotaj) için Web Audio entegrasyonu
- 2'den fazla oyuncu / takım modu
